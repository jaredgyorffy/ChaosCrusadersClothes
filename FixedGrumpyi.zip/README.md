A custom suit mod for the Chaos Crusaders! Also Includes several of the skins from the More Skins Mod.

Adds suits:
- Connor
- Grumpy Bear (Carebears)
- Blastoise (Pokemon)
- Socks the Cat
- Danny Phantom (He's a Phantom)


Removes Suits:
- Racist Knuckles
- Smile
- Mario
- Luigi
- Skeleton
