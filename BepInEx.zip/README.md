A custom suit mod for the Chaos Crusaders! Currently includes several of the suits from the default MoreSuits Mod.

Adds suits:
- Connor
- Grumpy Bear (Carebears)
- Blastoise (Pokemon)
- Socks the Cat


Removes Suits:
- Racist Knuckles
- Smile
